__version__ = 0.1
__author__  = "thautwarm"
__lisence__ = "MIT"
"""

See flowpython grammar in https://github.com/thautwarm/flowpython
"""

