__version__ = "0.1.2"
__author__  = "thautwarm"
__lisence__ = "MIT"
"""
Additional 

See flowpython grammar in https://github.com/thautwarm/flowpython
"""

