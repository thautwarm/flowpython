import sys,os,platform

reps = {
		'python3.dll',
		'python36.dll',
		'pythonw.exe',
		'python.exe'
		}
		
if __name__ == "__main__":
	paths = sys.path
	root_flowpy = os.path.abspath('./bin')
	root_to_oripy = os.path.abspath('./oripy')
	root_flowpy32 = os.path.abspath('./x32')
	root_flowpy_linux64 = os.path.abspath('./linux/python')

	proc = platform.architecture()[0]
	if 'windows' in platform.platform().lower():
		print('on windows..')
		for path in paths:
			if path in [root_flowpy32, root_flowpy,root_to_oripy] :continue
			if not os.path.isdir(path):
				if 'python' in path:
					filenames =[path]
				else:
					continue
			else:
				filenames = os.listdir(path)
			if 'python3.dll' in filenames and 'python.exe' in filenames:
				root_oripy   = path
				for rep in reps:
					from_to = os.path.join(path, rep)
					from_   = os.path.join(root_flowpy,rep) if proc == '64bit' else os.path.join(root_flowpy32, rep)
					os.rename(from_to , os.path.join(root_to_oripy, rep))
					print(f"write {from_} to {from_to}...")
					with open(from_to,'wb') as f1, open(from_,'rb') as f2:
						f1.write(f2.read())
	elif 'linux' in platform.platform().lower():
		print('on linux/debian x64..')
		if proc == '32bit':
			raise "do not support 32bit linux..."
		for path in paths:
			if path in [root_flowpy32, root_flowpy,root_to_oripy,  os.path.abspath('./linux/')] :continue
			if not os.path.isdir(path):
				print(path)
				if 'python' in path:
					filenames = [path]
				else:
					continue
			else:
				filenames = os.listdir(path)
			for python in ('python3.6','python'):
				if python in filenames:
					print(python)
					root_oripy   = path
					from_to = os.path.join(path,path)
					from_   = root_flowpy_linux64
					os.rename(from_to , os.path.join(root_to_oripy, python))
					print(f"write {from_} to {from_to}...")
					with open(from_to,'wb') as f1, open(from_,'rb') as f2:
						f1.write(f2.read())
					break
	else:
		print("unknown platform...")




